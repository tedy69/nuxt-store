<template>
  <div class="section statistics" id="statistic">
    <div class="title">
      <span>STATS</span>
      <h2>Our Statistics</h2>
    </div>

    <div class="row container">
      <div class="col">
        <div class="icon">
          <em class="bx bxs-check-square"></em>
        </div>
        <h3>Easy Order System</h3>
        <p>Lorem Ispum is a placeholder text commomly used as a free text.</p>
      </div>
      <div class="col">
        <div class="icon">
          <em class="bx bxs-user"></em>
        </div>
        <h3>On Time Delievery</h3>
        <p>Lorem Ispum is a placeholder text commomly used as a free text.</p>
      </div>
      <div class="col">
        <div class="icon">
          <em class="bx bxs-dollar-circle"></em>
        </div>
        <h3>Money Back Gaurantee</h3>
        <p>Lorem Ispum is a placeholder text commomly used as a free text.</p>
      </div>
      <div class="col">
        <div class="icon">
          <em class="bx bxs-user"></em>
        </div>
        <h3>24/7 Customer Support</h3>
        <p>Lorem Ispum is a placeholder text commomly used as a free text.</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>