<template>
  <div class="section new-arrival" id="new-arrival">
    <div class="title">
      <span>NEW ARRIVAL</span>
      <h2>Latest Collection</h2>
    </div>

    <div class="row container">
      <div class="col col-1">
        <img src="~assets/img/poster-1.png" alt="" />
        <h3>
          2022 Trends <br />
          Women’s Smart Skirt
        </h3>
      </div>
      <div class="col col-2">
        <img src="~assets/img/poster-2.png" alt="" />
        <h3>
          2022 Trends <br />
          Women’s Smart Skirt
        </h3>
      </div>
      <div class="col col-3">
        <img src="~assets/img/poster-3.png" alt="" />
        <h3>
          2022 Trends <br />
          Women’s Smart Shirt <br />
          <span>Discover More:</span>
        </h3>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>