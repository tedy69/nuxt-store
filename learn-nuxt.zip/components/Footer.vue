<template>
  <footer class="footer" id="about-us">
    <div class="row container">
      <div class="col">
        <div class="logo d-flex">
          <img src="~assets/img/logo.svg" alt="logo" width="50" />
          <h3>Nuxt Store</h3>
        </div>
        <p>
          More Sales Channels; Payment Providers & Shipping Features Than Other
          Ecommerce Platforms.
        </p>
        <div class="icons d-flex">
          <div class="icon d-flex">
            <a href="https://facebook.com/mochtedyfazrin" target="_blank">
              <em class="bx bxl-facebook"></em
            ></a>
          </div>
          <div class="icon d-flex">
            <a href="https://github.com/tedy69" target="_blank">
              <em class="bx bxl-github"></em
            ></a>
          </div>
          <div class="icon d-flex">
            <a href="https://instagram.com/tedyfazrin_" target="_blank"
              ><em class="bx bxl-instagram"></em
            ></a>
          </div>
          <div class="icon d-flex">
            <a
              href="https://www.youtube.com/channel/UCU5_fO6VuHb3p2ysALEzg4Q"
              target="_blank"
              ><em class="bx bxl-youtube"></em
            ></a>
          </div>
        </div>
        <p class="color">
          Copyrights 2022 <br />
          Tedy Fazrin
        </p>
      </div>
      <div class="col">
        <div>
          <h4>Product</h4>
          <a href="">Download</a>
          <a href="">Pricing</a>
          <a href="">Locations</a>
          <a href="">Server</a>
          <a href="">Countries</a>
          <a href="">Blog</a>
        </div>
        <div>
          <h4>Category</h4>
          <a href="">Men</a>
          <a href="">Women</a>
          <a href="">Kids</a>
          <a href="">Best Seller</a>
          <a href="">New Arrivals</a>
        </div>
        <div>
          <h4>My Account</h4>
          <a href="">My Account</a>
          <a href="">Discount</a>
          <a href="">Returns</a>
          <a href="">Order History</a>
          <a href="">Order Tracking</a>
        </div>
        <div>
          <h4>Contact Us</h4>
          <div class="d-flex">
            <div class="icon"><em class="bx bxs-map"></em></div>
            <span
              >Jl. Sindang Sirna No.38, Gegerkalong, Kec. Sukajadi, Kota
              Bandung, Jawa Barat, 40153</span
            >
          </div>
          <div class="d-flex">
            <div class="icon"><em class="bx bxs-envelope"></em></div>
            <span>gmail@tedyfazrin.com</span>
          </div>
          <div class="d-flex">
            <div class="icon"><em class="bx bxs-phone"></em></div>
            <span>+62 8138 0713 411</span>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {};
</script>

<style>
</style>