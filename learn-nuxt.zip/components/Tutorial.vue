<!-- Please remove this file from your project -->
<template>
  <div></div>
</template>

<script>
export default {
  name: "NuxtTutorial",
};
</script>
