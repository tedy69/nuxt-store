<template>
  <div class="hero">
    <div class="row container d-flex">
      <div class="col">
        <span class="subtitle">Limited Time Only For Winter</span>
        <h1>fash<span class="i">i</span>on</h1>
        <p>LOOK YOUR BEST ON YOUR BEST DAY</p>

        <button class="btn">Explore Now!</button>
      </div>
      <img src="~assets/img/woman-in-cart.png" alt="" />
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>