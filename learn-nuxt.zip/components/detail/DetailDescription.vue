<template>
  <section class="detail-des">
    <h1
      class="section-title font-cinzle"
      style="
        font-family: cinzel, sans-serif;
        font-weight: bold;
        margin-bottom: 30px;
      "
    >
      details
    </h1>
    <p class="des">
      Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nemo
      accusantium, modi nihil fugiat atque voluptas accusamus quae tempora culpa
      unde a ut sapiente minus laboriosam repellendus? Minima rerum qui hic est
      in soluta impedit itaque provident, exercitationem vel magnam perspiciatis
      esse? Quasi vero nihil ducimus assumenda obcaecati fugiat maxime officiis
      quaerat asperiores architecto sed, iure sapiente, sint ipsam laudantium at
      a nemo deserunt quod in repudiandae, sunt reiciendis.
    </p>
  </section>
</template>

<script>
export default {};
</script>

<style>
</style>