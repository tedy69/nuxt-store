export const Banner = () => import('../..\\components\\Banner.vue' /* webpackChunkName: "components/banner" */).then(c => wrapFunctional(c.default || c))
export const Categories = () => import('../..\\components\\Categories.vue' /* webpackChunkName: "components/categories" */).then(c => wrapFunctional(c.default || c))
export const Collection = () => import('../..\\components\\Collection.vue' /* webpackChunkName: "components/collection" */).then(c => wrapFunctional(c.default || c))
export const Footer = () => import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const NavBar = () => import('../..\\components\\NavBar.vue' /* webpackChunkName: "components/nav-bar" */).then(c => wrapFunctional(c.default || c))
export const NewArrival = () => import('../..\\components\\NewArrival.vue' /* webpackChunkName: "components/new-arrival" */).then(c => wrapFunctional(c.default || c))
export const NuxtLogo = () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const Product = () => import('../..\\components\\Product.vue' /* webpackChunkName: "components/product" */).then(c => wrapFunctional(c.default || c))
export const Review = () => import('../..\\components\\Review.vue' /* webpackChunkName: "components/review" */).then(c => wrapFunctional(c.default || c))
export const Statistic = () => import('../..\\components\\Statistic.vue' /* webpackChunkName: "components/statistic" */).then(c => wrapFunctional(c.default || c))
export const Tutorial = () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
export const DetailComment = () => import('../..\\components\\detail\\Comment.vue' /* webpackChunkName: "components/detail-comment" */).then(c => wrapFunctional(c.default || c))
export const DetailDescription = () => import('../..\\components\\detail\\DetailDescription.vue' /* webpackChunkName: "components/detail-description" */).then(c => wrapFunctional(c.default || c))
export const DetailProduct = () => import('../..\\components\\detail\\DetailProduct.vue' /* webpackChunkName: "components/detail-product" */).then(c => wrapFunctional(c.default || c))
export const DetailReview = () => import('../..\\components\\detail\\Review.vue' /* webpackChunkName: "components/detail-review" */).then(c => wrapFunctional(c.default || c))
export const DetailSimilar = () => import('../..\\components\\detail\\Similar.vue' /* webpackChunkName: "components/detail-similar" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
