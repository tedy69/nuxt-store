# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Banner>` | `<banner>` (components/Banner.vue)
- `<Categories>` | `<categories>` (components/Categories.vue)
- `<Collection>` | `<collection>` (components/Collection.vue)
- `<Footer>` | `<footer>` (components/Footer.vue)
- `<NavBar>` | `<nav-bar>` (components/NavBar.vue)
- `<NewArrival>` | `<new-arrival>` (components/NewArrival.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<Product>` | `<product>` (components/Product.vue)
- `<Review>` | `<review>` (components/Review.vue)
- `<Statistic>` | `<statistic>` (components/Statistic.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<DetailComment>` | `<detail-comment>` (components/detail/Comment.vue)
- `<DetailDescription>` | `<detail-description>` (components/detail/DetailDescription.vue)
- `<DetailProduct>` | `<detail-product>` (components/detail/DetailProduct.vue)
- `<DetailReview>` | `<detail-review>` (components/detail/Review.vue)
- `<DetailSimilar>` | `<detail-similar>` (components/detail/Similar.vue)
